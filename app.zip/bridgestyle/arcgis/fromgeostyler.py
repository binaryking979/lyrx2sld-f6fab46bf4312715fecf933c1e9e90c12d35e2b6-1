
def convert(geostyler, options=None):
    return {}, [] # (dictionary with ArcGIS Pro style, list of warnings)
