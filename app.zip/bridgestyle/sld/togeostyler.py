def convert(geostyler, options=None):
    return {}, []
