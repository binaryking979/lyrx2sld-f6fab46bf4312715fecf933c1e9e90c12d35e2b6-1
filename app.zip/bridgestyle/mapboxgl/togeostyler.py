def convert(style, options=None):
    pass  # TODO
